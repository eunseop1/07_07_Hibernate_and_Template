package kr.human.job.app;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//http://websystique.com/spring/spring-job-scheduling-using-xml-configuration/
public class AppMain {
	public static void main(String[] args) {
		AbstractApplicationContext context =
				new ClassPathXmlApplicationContext("AppConfig.xml");
		
		//context.close();//닫으면 바로 종료이기에 안된다. 얘는 계속 돌아야만 한다
	}


}